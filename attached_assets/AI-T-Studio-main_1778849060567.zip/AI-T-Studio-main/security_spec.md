# Firestore Security Spec

## 1. Data Invariants

- Users:
    - `tokens` must be a number.
    - `accumulatedDiscount` must be a number or null.
- Designs:
    - `ownerId` must be the same as the authenticated user's `uid`.
    - `image` must be a string.
    - `prompt` must be a string.
    - `createdAt` must be the server timestamp.

## 2. The "Dirty Dozen" Payloads

(A list of payloads I intend to test against the rules)

## 3. The Test Runner

(I will create a `firestore.rules.test.ts` file next)
