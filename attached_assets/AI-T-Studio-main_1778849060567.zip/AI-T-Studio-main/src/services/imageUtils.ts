export async function removeWhiteBackground(imageUrl: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous"; // Important to avoid CORS issues
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject('No context available');
      ctx.drawImage(img, 0, 0);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;

      // Threshold: pixels brighter than this in all RGB channels are made transparent
      // Ajustado para 200 para remover também o cinza claro do quadriculado de fundo
      const threshold = 200; 
      for (let i = 0; i < data.length; i += 4) {
        if (data[i] > threshold && data[i+1] > threshold && data[i+2] > threshold) {
          data[i+3] = 0; // Set Alpha to 0
        }
      }
      ctx.putImageData(imageData, 0, 0);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = () => reject('Failed to load image');
    img.src = imageUrl;
  });
}
