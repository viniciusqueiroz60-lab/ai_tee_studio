# AI T-Studio

AI T-Studio is a web-based workshop management application designed for managing t-shirt design and production workflows.

## Technology Stack

- **Frontend Framework:** React 18+ with Vite
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **Authentication:** Firebase Authentication (Google Provider)
- **Database:** Firebase Cloud Firestore
- **Build Tool:** Vite

## Infrastructure Requirements

To run and deploy this application, you need the following infrastructure and services:

1.  **Node.js Environment:** The project requires a standard Node.js environment (latest LTS recommended).
2.  **Firebase Project:** A Firebase project is required to handle authentication and data persistence.
    - **Firestore:** Needed for database storage.
    - **Authentication:** Needed for user management.
3.  **Google Cloud Platform (GCP):** Used for hosting and service management.

## Setup Instructions

### 1. Prerequisite

Ensure you have [Node.js](https://nodejs.org/) installed.

### 2. Install Dependencies

Install all required npm packages:

```bash
npm install
```

### 3. Environment Configuration

Copy the example environment file and populate it with your necessary API keys and configuration:

```bash
cp .env.example .env
```

*Note: Never commit your `.env` file containing actual secrets to version control.*

### 4. Firebase Configuration

The application requires a `firebase-applet-config.json` file. Ensure this is properly populated with your Firebase project configuration (API keys, project ID, etc.).

### 5. Running in Development

To start the development server:

```bash
npm run dev
```

The application will be accessible via the provided local development URL.

### 6. Production Build

To build the application for production deployment:

```bash
npm run build
```

The production assets will be generated in the `dist/` directory.

## Core File Manifest

- `src/App.tsx`: The main application component.
- `firestore.rules`: Security rules for Firestore, defining access control.
- `firebase-blueprint.json`: IR of the database structure.
- `public/logo.png`: Application logo.
- `metadata.json`: App application settings.
